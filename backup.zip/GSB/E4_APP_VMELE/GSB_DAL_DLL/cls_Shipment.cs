﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_Commandes
{
    public class cls_Shipment : cls_ObjetBase
    {
        private int c_IDShipment;
        private string c_RefShipment;
        private DateTime c_DateEnvoi;
        private int c_IDCommande;

        cls_Shipment(int pIDShipment, string pRefShipment, DateTime pDateEnvoi, 
            int pIDCommande) : base (pIDShipment)
        {
            setRefShipment(pIDShipment);
            c_DateEnvoi = pDateEnvoi;
            c_IDCommande = pIDCommande;
        }

        /// <summary>
        /// Assigne SH/00 + l'ID du shipment pour sa référence
        /// </summary>
        /// <param name="pRefShipment">Référence à modifier</param>
        /// <param name="pIDShipment">ID du shipment</param>
        public void setRefShipment(int pIDShipment)
        {
            c_RefShipment = "SH/00" + pIDShipment;
        }

        public string RefShipment
        {
            get
            {
                return c_RefShipment;
            }
            set
            {
                c_RefShipment = value;
            }
        }
        public DateTime DateEnvoi
        {
            get
            {
                return c_DateEnvoi;
            }
            set
            {
                c_DateEnvoi = value;
            }
        }
        public int idCommande
        {
            get
            {
                return c_IDCommande;
            }
            set
            {
                c_IDCommande = value;
            }
        }

    }
}
