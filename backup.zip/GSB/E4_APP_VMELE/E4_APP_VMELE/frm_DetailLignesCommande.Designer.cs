﻿namespace E4_APP_VMELE
{
    partial class frm_DetailLignesCommande
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_refCommande = new System.Windows.Forms.TextBox();
            this.tbx_noSol = new System.Windows.Forms.TextBox();
            this.tbx_conditionnement = new System.Windows.Forms.TextBox();
            this.tbx_prixConditionne = new System.Windows.Forms.TextBox();
            this.tbx_produit = new System.Windows.Forms.TextBox();
            this.tbx_quantite = new System.Windows.Forms.TextBox();
            this.tbx_montantTotal = new System.Windows.Forms.TextBox();
            this.cbx_tva = new System.Windows.Forms.ComboBox();
            this.btn_annuler = new System.Windows.Forms.Button();
            this.btn_enregistrer = new System.Windows.Forms.Button();
            this.btn_valider = new System.Windows.Forms.Button();
            this.pgb_statut = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_refCommande
            // 
            this.tbx_refCommande.Location = new System.Drawing.Point(69, 107);
            this.tbx_refCommande.Name = "tbx_refCommande";
            this.tbx_refCommande.Size = new System.Drawing.Size(147, 22);
            this.tbx_refCommande.TabIndex = 0;
            // 
            // tbx_noSol
            // 
            this.tbx_noSol.Location = new System.Drawing.Point(245, 107);
            this.tbx_noSol.Name = "tbx_noSol";
            this.tbx_noSol.Size = new System.Drawing.Size(100, 22);
            this.tbx_noSol.TabIndex = 1;
            // 
            // tbx_conditionnement
            // 
            this.tbx_conditionnement.Location = new System.Drawing.Point(524, 107);
            this.tbx_conditionnement.Name = "tbx_conditionnement";
            this.tbx_conditionnement.Size = new System.Drawing.Size(116, 22);
            this.tbx_conditionnement.TabIndex = 2;
            // 
            // tbx_prixConditionne
            // 
            this.tbx_prixConditionne.Location = new System.Drawing.Point(651, 107);
            this.tbx_prixConditionne.Name = "tbx_prixConditionne";
            this.tbx_prixConditionne.Size = new System.Drawing.Size(111, 22);
            this.tbx_prixConditionne.TabIndex = 3;
            // 
            // tbx_produit
            // 
            this.tbx_produit.Location = new System.Drawing.Point(69, 181);
            this.tbx_produit.Name = "tbx_produit";
            this.tbx_produit.Size = new System.Drawing.Size(249, 22);
            this.tbx_produit.TabIndex = 4;
            // 
            // tbx_quantite
            // 
            this.tbx_quantite.Location = new System.Drawing.Point(418, 107);
            this.tbx_quantite.Name = "tbx_quantite";
            this.tbx_quantite.Size = new System.Drawing.Size(100, 22);
            this.tbx_quantite.TabIndex = 5;
            // 
            // tbx_montantTotal
            // 
            this.tbx_montantTotal.Location = new System.Drawing.Point(630, 181);
            this.tbx_montantTotal.Name = "tbx_montantTotal";
            this.tbx_montantTotal.Size = new System.Drawing.Size(100, 22);
            this.tbx_montantTotal.TabIndex = 6;
            // 
            // cbx_tva
            // 
            this.cbx_tva.FormattingEnabled = true;
            this.cbx_tva.Location = new System.Drawing.Point(469, 181);
            this.cbx_tva.Name = "cbx_tva";
            this.cbx_tva.Size = new System.Drawing.Size(121, 24);
            this.cbx_tva.TabIndex = 7;
            // 
            // btn_annuler
            // 
            this.btn_annuler.Location = new System.Drawing.Point(33, 356);
            this.btn_annuler.Name = "btn_annuler";
            this.btn_annuler.Size = new System.Drawing.Size(149, 39);
            this.btn_annuler.TabIndex = 8;
            this.btn_annuler.Text = "Annuler la ligne";
            this.btn_annuler.UseVisualStyleBackColor = true;
            // 
            // btn_enregistrer
            // 
            this.btn_enregistrer.Location = new System.Drawing.Point(727, 356);
            this.btn_enregistrer.Name = "btn_enregistrer";
            this.btn_enregistrer.Size = new System.Drawing.Size(149, 39);
            this.btn_enregistrer.TabIndex = 9;
            this.btn_enregistrer.Text = "Enregistrer";
            this.btn_enregistrer.UseVisualStyleBackColor = true;
            // 
            // btn_valider
            // 
            this.btn_valider.Location = new System.Drawing.Point(350, 356);
            this.btn_valider.Name = "btn_valider";
            this.btn_valider.Size = new System.Drawing.Size(149, 39);
            this.btn_valider.TabIndex = 9;
            this.btn_valider.Text = "Valider la ligne";
            this.btn_valider.UseVisualStyleBackColor = true;
            // 
            // pgb_statut
            // 
            this.pgb_statut.Location = new System.Drawing.Point(300, 289);
            this.pgb_statut.Name = "pgb_statut";
            this.pgb_statut.Size = new System.Drawing.Size(246, 23);
            this.pgb_statut.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Référence commande";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(242, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 13;
            this.label2.Text = "No. ligne";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(415, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Quantité";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(521, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "Conditionnement";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(643, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 16;
            this.label5.Text = "Prix conditionné";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Produit";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(466, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "TVA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(627, 161);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "Montant total";
            // 
            // frm_DetailLignesCommande
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.CancelButton = this.btn_annuler;
            this.ClientSize = new System.Drawing.Size(929, 418);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pgb_statut);
            this.Controls.Add(this.btn_valider);
            this.Controls.Add(this.btn_enregistrer);
            this.Controls.Add(this.btn_annuler);
            this.Controls.Add(this.cbx_tva);
            this.Controls.Add(this.tbx_montantTotal);
            this.Controls.Add(this.tbx_quantite);
            this.Controls.Add(this.tbx_produit);
            this.Controls.Add(this.tbx_prixConditionne);
            this.Controls.Add(this.tbx_conditionnement);
            this.Controls.Add(this.tbx_noSol);
            this.Controls.Add(this.tbx_refCommande);
            this.Name = "frm_DetailLignesCommande";
            this.Text = "GSB Commande - Détail ligne de commande";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_refCommande;
        private System.Windows.Forms.TextBox tbx_noSol;
        private System.Windows.Forms.TextBox tbx_conditionnement;
        private System.Windows.Forms.TextBox tbx_prixConditionne;
        private System.Windows.Forms.TextBox tbx_produit;
        private System.Windows.Forms.TextBox tbx_quantite;
        private System.Windows.Forms.TextBox tbx_montantTotal;
        private System.Windows.Forms.ComboBox cbx_tva;
        private System.Windows.Forms.Button btn_annuler;
        private System.Windows.Forms.Button btn_enregistrer;
        private System.Windows.Forms.Button btn_valider;
        private System.Windows.Forms.ProgressBar pgb_statut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}