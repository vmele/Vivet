﻿namespace E4_APP_VMELE
{
    partial class frm_Listes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tctrl_ListeCommande = new System.Windows.Forms.TabControl();
            this.tpg_listeCommandes = new System.Windows.Forms.TabPage();
            this.btn_ajouterCommande = new System.Windows.Forms.Button();
            this.btn_soRechercher = new System.Windows.Forms.Button();
            this.btn_soVider = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cbx_soStatut = new System.Windows.Forms.ComboBox();
            this.tbx_soRefCommande = new System.Windows.Forms.TextBox();
            this.dgv_listeCommandes = new System.Windows.Forms.DataGridView();
            this.tpg_lignesCommande = new System.Windows.Forms.TabPage();
            this.btn_ajouteLigne = new System.Windows.Forms.Button();
            this.btn_solRechercher = new System.Windows.Forms.Button();
            this.btn_solVider = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbx_montantTotal = new System.Windows.Forms.TextBox();
            this.tbx_prixConditionne = new System.Windows.Forms.TextBox();
            this.tbx_conditionnement = new System.Windows.Forms.TextBox();
            this.tbx_quantite = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tbx_noSol = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbx_produit = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cbx_solStatut = new System.Windows.Forms.ComboBox();
            this.tbx_solRefCommande = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tctrl_ListeCommande.SuspendLayout();
            this.tpg_listeCommandes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_listeCommandes)).BeginInit();
            this.tpg_lignesCommande.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tctrl_ListeCommande
            // 
            this.tctrl_ListeCommande.Controls.Add(this.tpg_listeCommandes);
            this.tctrl_ListeCommande.Controls.Add(this.tpg_lignesCommande);
            this.tctrl_ListeCommande.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tctrl_ListeCommande.Location = new System.Drawing.Point(0, 0);
            this.tctrl_ListeCommande.Name = "tctrl_ListeCommande";
            this.tctrl_ListeCommande.SelectedIndex = 0;
            this.tctrl_ListeCommande.Size = new System.Drawing.Size(944, 719);
            this.tctrl_ListeCommande.TabIndex = 0;
            // 
            // tpg_listeCommandes
            // 
            this.tpg_listeCommandes.Controls.Add(this.btn_ajouterCommande);
            this.tpg_listeCommandes.Controls.Add(this.btn_soRechercher);
            this.tpg_listeCommandes.Controls.Add(this.btn_soVider);
            this.tpg_listeCommandes.Controls.Add(this.label6);
            this.tpg_listeCommandes.Controls.Add(this.label5);
            this.tpg_listeCommandes.Controls.Add(this.label4);
            this.tpg_listeCommandes.Controls.Add(this.label3);
            this.tpg_listeCommandes.Controls.Add(this.label2);
            this.tpg_listeCommandes.Controls.Add(this.dateTimePicker2);
            this.tpg_listeCommandes.Controls.Add(this.comboBox2);
            this.tpg_listeCommandes.Controls.Add(this.textBox2);
            this.tpg_listeCommandes.Controls.Add(this.label1);
            this.tpg_listeCommandes.Controls.Add(this.dateTimePicker1);
            this.tpg_listeCommandes.Controls.Add(this.cbx_soStatut);
            this.tpg_listeCommandes.Controls.Add(this.tbx_soRefCommande);
            this.tpg_listeCommandes.Controls.Add(this.dgv_listeCommandes);
            this.tpg_listeCommandes.Location = new System.Drawing.Point(4, 25);
            this.tpg_listeCommandes.Name = "tpg_listeCommandes";
            this.tpg_listeCommandes.Padding = new System.Windows.Forms.Padding(3);
            this.tpg_listeCommandes.Size = new System.Drawing.Size(936, 690);
            this.tpg_listeCommandes.TabIndex = 0;
            this.tpg_listeCommandes.Text = "Liste des commandes";
            this.tpg_listeCommandes.UseVisualStyleBackColor = true;
            // 
            // btn_ajouterCommande
            // 
            this.btn_ajouterCommande.Location = new System.Drawing.Point(783, 6);
            this.btn_ajouterCommande.Name = "btn_ajouterCommande";
            this.btn_ajouterCommande.Size = new System.Drawing.Size(142, 23);
            this.btn_ajouterCommande.TabIndex = 41;
            this.btn_ajouterCommande.Text = "Créer commande";
            this.btn_ajouterCommande.UseVisualStyleBackColor = true;
            this.btn_ajouterCommande.Click += new System.EventHandler(this.btn_ajouterCommande_Click);
            // 
            // btn_soRechercher
            // 
            this.btn_soRechercher.Location = new System.Drawing.Point(194, 109);
            this.btn_soRechercher.Name = "btn_soRechercher";
            this.btn_soRechercher.Size = new System.Drawing.Size(142, 23);
            this.btn_soRechercher.TabIndex = 40;
            this.btn_soRechercher.Text = "Rechercher";
            this.btn_soRechercher.UseVisualStyleBackColor = true;
            // 
            // btn_soVider
            // 
            this.btn_soVider.Location = new System.Drawing.Point(21, 109);
            this.btn_soVider.Name = "btn_soVider";
            this.btn_soVider.Size = new System.Drawing.Size(136, 23);
            this.btn_soVider.TabIndex = 39;
            this.btn_soVider.Text = "Vider les filtres";
            this.btn_soVider.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(591, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Date demandée";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(591, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Date commande";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(443, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "GC";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(302, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Client";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(146, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Statut";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(594, 110);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 8;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(446, 46);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(305, 46);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Réf. commande";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(594, 48);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // cbx_soStatut
            // 
            this.cbx_soStatut.FormattingEnabled = true;
            this.cbx_soStatut.Location = new System.Drawing.Point(149, 46);
            this.cbx_soStatut.Name = "cbx_soStatut";
            this.cbx_soStatut.Size = new System.Drawing.Size(121, 24);
            this.cbx_soStatut.TabIndex = 2;
            // 
            // tbx_soRefCommande
            // 
            this.tbx_soRefCommande.Location = new System.Drawing.Point(21, 46);
            this.tbx_soRefCommande.Name = "tbx_soRefCommande";
            this.tbx_soRefCommande.Size = new System.Drawing.Size(100, 22);
            this.tbx_soRefCommande.TabIndex = 1;
            // 
            // dgv_listeCommandes
            // 
            this.dgv_listeCommandes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_listeCommandes.Location = new System.Drawing.Point(6, 138);
            this.dgv_listeCommandes.Name = "dgv_listeCommandes";
            this.dgv_listeCommandes.RowTemplate.Height = 24;
            this.dgv_listeCommandes.Size = new System.Drawing.Size(919, 521);
            this.dgv_listeCommandes.TabIndex = 0;
            // 
            // tpg_lignesCommande
            // 
            this.tpg_lignesCommande.Controls.Add(this.btn_ajouteLigne);
            this.tpg_lignesCommande.Controls.Add(this.btn_solRechercher);
            this.tpg_lignesCommande.Controls.Add(this.btn_solVider);
            this.tpg_lignesCommande.Controls.Add(this.label14);
            this.tpg_lignesCommande.Controls.Add(this.label9);
            this.tpg_lignesCommande.Controls.Add(this.label8);
            this.tpg_lignesCommande.Controls.Add(this.label7);
            this.tpg_lignesCommande.Controls.Add(this.tbx_montantTotal);
            this.tpg_lignesCommande.Controls.Add(this.tbx_prixConditionne);
            this.tpg_lignesCommande.Controls.Add(this.tbx_conditionnement);
            this.tpg_lignesCommande.Controls.Add(this.tbx_quantite);
            this.tpg_lignesCommande.Controls.Add(this.label13);
            this.tpg_lignesCommande.Controls.Add(this.tbx_noSol);
            this.tpg_lignesCommande.Controls.Add(this.label10);
            this.tpg_lignesCommande.Controls.Add(this.label11);
            this.tpg_lignesCommande.Controls.Add(this.tbx_produit);
            this.tpg_lignesCommande.Controls.Add(this.label12);
            this.tpg_lignesCommande.Controls.Add(this.cbx_solStatut);
            this.tpg_lignesCommande.Controls.Add(this.tbx_solRefCommande);
            this.tpg_lignesCommande.Controls.Add(this.dataGridView1);
            this.tpg_lignesCommande.Location = new System.Drawing.Point(4, 25);
            this.tpg_lignesCommande.Name = "tpg_lignesCommande";
            this.tpg_lignesCommande.Padding = new System.Windows.Forms.Padding(3);
            this.tpg_lignesCommande.Size = new System.Drawing.Size(936, 690);
            this.tpg_lignesCommande.TabIndex = 1;
            this.tpg_lignesCommande.Text = "Liste des lignes de commande";
            this.tpg_lignesCommande.UseVisualStyleBackColor = true;
            // 
            // btn_ajouteLigne
            // 
            this.btn_ajouteLigne.Location = new System.Drawing.Point(794, 114);
            this.btn_ajouteLigne.Name = "btn_ajouteLigne";
            this.btn_ajouteLigne.Size = new System.Drawing.Size(111, 47);
            this.btn_ajouteLigne.TabIndex = 39;
            this.btn_ajouteLigne.Text = "Créer ligne";
            this.btn_ajouteLigne.UseVisualStyleBackColor = true;
            this.btn_ajouteLigne.Click += new System.EventHandler(this.btn_ajouteLigne_Click);
            // 
            // btn_solRechercher
            // 
            this.btn_solRechercher.Location = new System.Drawing.Point(195, 138);
            this.btn_solRechercher.Name = "btn_solRechercher";
            this.btn_solRechercher.Size = new System.Drawing.Size(142, 23);
            this.btn_solRechercher.TabIndex = 38;
            this.btn_solRechercher.Text = "Rechercher";
            this.btn_solRechercher.UseVisualStyleBackColor = true;
            // 
            // btn_solVider
            // 
            this.btn_solVider.Location = new System.Drawing.Point(22, 138);
            this.btn_solVider.Name = "btn_solVider";
            this.btn_solVider.Size = new System.Drawing.Size(136, 23);
            this.btn_solVider.TabIndex = 37;
            this.btn_solVider.Text = "Vider les filtres";
            this.btn_solVider.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(729, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 17);
            this.label14.TabIndex = 36;
            this.label14.Text = "Montant total";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(610, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "Prix cdt";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(479, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 17);
            this.label8.TabIndex = 34;
            this.label8.Text = "Conditionnement";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(350, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 33;
            this.label7.Text = "Quantité";
            // 
            // tbx_montantTotal
            // 
            this.tbx_montantTotal.Location = new System.Drawing.Point(732, 38);
            this.tbx_montantTotal.Name = "tbx_montantTotal";
            this.tbx_montantTotal.Size = new System.Drawing.Size(77, 22);
            this.tbx_montantTotal.TabIndex = 32;
            // 
            // tbx_prixConditionne
            // 
            this.tbx_prixConditionne.Location = new System.Drawing.Point(613, 36);
            this.tbx_prixConditionne.Name = "tbx_prixConditionne";
            this.tbx_prixConditionne.Size = new System.Drawing.Size(77, 22);
            this.tbx_prixConditionne.TabIndex = 31;
            // 
            // tbx_conditionnement
            // 
            this.tbx_conditionnement.Location = new System.Drawing.Point(482, 36);
            this.tbx_conditionnement.Name = "tbx_conditionnement";
            this.tbx_conditionnement.Size = new System.Drawing.Size(111, 22);
            this.tbx_conditionnement.TabIndex = 30;
            // 
            // tbx_quantite
            // 
            this.tbx_quantite.Location = new System.Drawing.Point(353, 38);
            this.tbx_quantite.Name = "tbx_quantite";
            this.tbx_quantite.Size = new System.Drawing.Size(77, 22);
            this.tbx_quantite.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 17);
            this.label13.TabIndex = 28;
            this.label13.Text = "No. SOL";
            // 
            // tbx_noSol
            // 
            this.tbx_noSol.Location = new System.Drawing.Point(22, 91);
            this.tbx_noSol.Name = "tbx_noSol";
            this.tbx_noSol.Size = new System.Drawing.Size(100, 22);
            this.tbx_noSol.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(180, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "Produit";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(147, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 17);
            this.label11.TabIndex = 22;
            this.label11.Text = "Statut";
            // 
            // tbx_produit
            // 
            this.tbx_produit.Location = new System.Drawing.Point(183, 91);
            this.tbx_produit.Name = "tbx_produit";
            this.tbx_produit.Size = new System.Drawing.Size(316, 22);
            this.tbx_produit.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 17);
            this.label12.TabIndex = 18;
            this.label12.Text = "Réf. commande";
            // 
            // cbx_solStatut
            // 
            this.cbx_solStatut.FormattingEnabled = true;
            this.cbx_solStatut.Location = new System.Drawing.Point(150, 36);
            this.cbx_solStatut.Name = "cbx_solStatut";
            this.cbx_solStatut.Size = new System.Drawing.Size(121, 24);
            this.cbx_solStatut.TabIndex = 16;
            // 
            // tbx_solRefCommande
            // 
            this.tbx_solRefCommande.Location = new System.Drawing.Point(22, 36);
            this.tbx_solRefCommande.Name = "tbx_solRefCommande";
            this.tbx_solRefCommande.Size = new System.Drawing.Size(100, 22);
            this.tbx_solRefCommande.TabIndex = 15;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 191);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(919, 458);
            this.dataGridView1.TabIndex = 14;
            // 
            // frm_Listes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 719);
            this.Controls.Add(this.tctrl_ListeCommande);
            this.Name = "frm_Listes";
            this.Text = "GSB Commande - Listes";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tctrl_ListeCommande.ResumeLayout(false);
            this.tpg_listeCommandes.ResumeLayout(false);
            this.tpg_listeCommandes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_listeCommandes)).EndInit();
            this.tpg_lignesCommande.ResumeLayout(false);
            this.tpg_lignesCommande.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tctrl_ListeCommande;
        private System.Windows.Forms.TabPage tpg_listeCommandes;
        private System.Windows.Forms.TabPage tpg_lignesCommande;
        private System.Windows.Forms.DataGridView dgv_listeCommandes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cbx_soStatut;
        private System.Windows.Forms.TextBox tbx_soRefCommande;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbx_noSol;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbx_produit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbx_solStatut;
        private System.Windows.Forms.TextBox tbx_solRefCommande;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbx_montantTotal;
        private System.Windows.Forms.TextBox tbx_prixConditionne;
        private System.Windows.Forms.TextBox tbx_conditionnement;
        private System.Windows.Forms.TextBox tbx_quantite;
        private System.Windows.Forms.Button btn_solRechercher;
        private System.Windows.Forms.Button btn_solVider;
        private System.Windows.Forms.Button btn_soRechercher;
        private System.Windows.Forms.Button btn_soVider;
        private System.Windows.Forms.Button btn_ajouteLigne;
        private System.Windows.Forms.Button btn_ajouterCommande;
    }
}