﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using dll_Commandes;

namespace E4_APP_VMELE
{
    public class cls_DAL_TypeCommande
    {

    }
}
