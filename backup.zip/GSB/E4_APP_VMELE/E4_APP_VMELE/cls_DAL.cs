﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using dll_Commandes;



namespace E4_APP_VMELE
{
    public class cls_DAL
    {
        static NpgsqlConnection c_Cnn;
        static cls_DAL_Commande s_DAL_Commande;
        static cls_DAL_Droit s_DAL_Droit;
        static cls_DAL_EtatSo s_DAL_EtatSo;
        static cls_DAL_EtatSol s_DAL_EtatSol;
        static cls_DAL_Facture s_DAL_Facture;
        static cls_DAL_LigneCommande s_DAL_LigneCommande;
        static cls_DAL_MoyenContact s_DAL_MoyenContact;
        static cls_DAL_Personne s_DAL_Personne;
        static cls_DAL_Produit s_DAL_Produit;
        static cls_DAL_Shipment s_DAL_Shipment;
        static cls_DAL_Tva s_DAL_Tva;
        static cls_DAL_TypeCommande s_DAL_TypeCommande;
        static cls_DAL_Utilisateur s_DAL_Utilisateur;

        public cls_DAL(string pServeur, string pNomUtilisateur, string pMP)
        {
            c_Cnn = new NpgsqlConnection("Host=" + pServeur + ";Username=" + pNomUtilisateur + ";Password=" + pMP + ";Database=e4_vmele");
            c_Cnn.Open();
            s_DAL_Commande = new cls_DAL_Commande();
            s_DAL_Droit = new cls_DAL_Droit();
            s_DAL_EtatSo = new cls_DAL_EtatSo();
            s_DAL_EtatSol = new cls_DAL_EtatSol();
            s_DAL_Facture = new cls_DAL_Facture();
            s_DAL_LigneCommande = new cls_DAL_LigneCommande();
            s_DAL_MoyenContact = new cls_DAL_MoyenContact();
            s_DAL_Personne = new cls_DAL_Personne();
            s_DAL_Produit = new cls_DAL_Produit();
            s_DAL_Shipment = new cls_DAL_Shipment();
            s_DAL_Tva = new cls_DAL_Tva();
            s_DAL_TypeCommande = new cls_DAL_TypeCommande();
            s_DAL_Utilisateur = new cls_DAL_Utilisateur();
        }



        public NpgsqlConnection Cnn
        {
            get
            {
                return c_Cnn;
            }
        }

        public static cls_DAL_Commande DALCommande { get; set; }
        public static cls_DAL_Droit DALDroit { get; set; }
        public static cls_DAL_EtatSo DALEtatSo { get; set; }
        public static cls_DAL_EtatSol DALEtatSol { get; set; }
        public static cls_DAL_Facture DALFacture { get; set; }
        public static cls_DAL_LigneCommande DALLigneCommande { get; set; }
        public static cls_DAL_MoyenContact DALMoyenContact { get; set; }
        public static cls_DAL_Personne DALPersonne { get; set; }
        public static cls_DAL_Produit DALProduit { get; set; }
        public static cls_DAL_Shipment DALShipment { get; set; }
        public static cls_DAL_Tva DALTva { get; set; }
        public static cls_DAL_TypeCommande DALTypeCommande { get; set; }
        public static cls_DAL_Utilisateur DALUtilisateur { get; set; }
    }
}
