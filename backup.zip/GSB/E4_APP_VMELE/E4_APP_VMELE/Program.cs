﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using dll_Commandes;

namespace E4_APP_VMELE
{
     static class Program
    {
        static cls_Modele s_Modele;
        static cls_Controlleur s_Controlleur;
        static cls_DAL s_DAL;


        //static cls_DAL_Commande s_DAL_Commande;
        //static cls_DAL_Droit s_DAL_Droit;
        //static cls_DAL_EtatSo s_DAL_EtatSo;
        //static cls_DAL_EtatSol s_DAL_EtatSol;
        //static cls_DAL_Facture s_DAL_Facture;
        //static cls_DAL_LigneCommande s_DAL_LigneCommande;
        //static cls_DAL_MoyenContact s_DAL_MoyenContact;
        //static cls_DAL_Personne s_DAL_Personne;
        //static cls_DAL_Produit s_DAL_Produit;
        //static cls_DAL_Shipment s_DAL_Shipment;
        //static cls_DAL_Tva s_DAL_Tva;
        //static cls_DAL_TypeCommande s_DAL_TypeCommande;
        //static cls_DAL_Utilisateur s_DAL_Utilisateur;


        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frm_Connexion());
        }

        static Program()
        {
            s_Controlleur = new cls_Controlleur();
            s_Modele = new cls_Modele();
            s_DAL = new cls_DAL("localhost", "postgres", "postgres");
            //s_DAL_Commande = new cls_DAL_Commande();
            //s_DAL_Droit = new cls_DAL_Droit();
            //s_DAL_EtatSo = new cls_DAL_EtatSo();
            //s_DAL_EtatSol = new cls_DAL_EtatSol();
            //s_DAL_Facture = new cls_DAL_Facture();
            //s_DAL_LigneCommande = new cls_DAL_LigneCommande();
            //s_DAL_MoyenContact = new cls_DAL_MoyenContact();
            //s_DAL_Personne = new cls_DAL_Personne();
            //s_DAL_Produit = new cls_DAL_Produit();
            //s_DAL_Shipment = new cls_DAL_Shipment();
            //s_DAL_Tva = new cls_DAL_Tva();
            //s_DAL_TypeCommande = new cls_DAL_TypeCommande();
            //s_DAL_Utilisateur = new cls_DAL_Utilisateur();
        }

        public static cls_Controlleur Controlleur
        {
            get
            {
                return s_Controlleur;
            }
        }
        public static cls_Modele Modele
        {
            get
            {
                return s_Modele;
            }
        }
        public static cls_DAL DAL
        {
            get
            {
                return s_DAL;
            }
        }
        //public static cls_DAL_Commande DALCommande { get; set; }
        //public static cls_DAL_Droit DALDroit { get; set; }
        //public static cls_DAL_EtatSo DALEtatSo { get; set; }
        //public static cls_DAL_EtatSol DALEtatSol { get; set; }
        //public static cls_DAL_Facture DALFacture { get; set; }
        //public static cls_DAL_LigneCommande DALLigneCommande { get; set; }
        //public static cls_DAL_MoyenContact DALMoyenContact { get; set; }
        //public static cls_DAL_Personne DALPersonne { get; set; }
        //public static cls_DAL_Produit DALProduit { get; set; }
        //public static cls_DAL_Shipment DALShipment { get; set; }
        //public static cls_DAL_Tva DALTva { get; set; }
        //public static cls_DAL_TypeCommande DALTypeCommande { get; set; }
        //public static cls_DAL_Utilisateur DALUtilisateur { get; set; }

    }
}
