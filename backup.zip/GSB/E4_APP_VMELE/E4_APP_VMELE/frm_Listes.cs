﻿using System;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using dll_Commandes;



namespace E4_APP_VMELE
{
    public partial class frm_Listes : Form
    {
        public frm_Listes()
        {
            InitializeComponent();
            CreationDesObjets(Program.Modele);
        }

        /// <summary>
        /// Appel pour remplir les deux listes.
        /// </summary>
        /// <param name="pModele">Appelle la classe Cls_Modele qui comporte les dictionnaires</param>
        private void CreationDesObjets(cls_Modele pModele)
        {
            pModele.ListeCommandes = cls_DAL_Commande.CreerListeCommande();
        }






        private void btn_ajouteLigne_Click(object sender, EventArgs e)
        {
            frm_DetailLignesCommande l_DetailLignesCommande = new frm_DetailLignesCommande();
            l_DetailLignesCommande.Show();
        }

        /// <summary>
        /// Fonction d'envoi de mail au support GSB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nouveauMailSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Outlook.Application outlookApp = new Outlook.Application();
                Outlook.MailItem mailItem = (Outlook.MailItem)outlookApp.CreateItem(Outlook.OlItemType.olMailItem);
                mailItem.Subject = Form.ActiveForm.Name;
                mailItem.To = "contact@valentinmele.fr";
                mailItem.Body = "This is the message.";
                mailItem.Importance = Outlook.OlImportance.olImportanceLow;
                mailItem.Display(false);
            }
            catch (Exception eX)
            {
                throw new Exception("cDocument: Error occurred trying to Create an Outlook Email"
                                    + Environment.NewLine + eX.Message);
            }
        }

        private void btn_ajouterCommande_Click(object sender, EventArgs e)
        {
            frm_DetailCommande l_detailCommande = new frm_DetailCommande();
            l_detailCommande.MdiParent = MDIParent.ActiveForm;
            l_detailCommande.Show();
        }
    }
}
