﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using dll_Commandes;


namespace E4_APP_VMELE
{
    public class cls_DAL_Commande
    {
        static NpgsqlConnection c_Cnn = Program.DAL.Cnn;

        /// <summary>
        /// Select et créé la liste des commandes
        /// </summary>
        /// <returns>Liste des commandes</returns>
        public static Dictionary<int, cls_Commande> CreerListeCommande()
        {
            cls_Commande l_Commande = null;
            Dictionary<int, cls_Commande> l_ListeCommande = new Dictionary<int, cls_Commande>();
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = c_Cnn;
                // Retrieve all rows
                cmd.CommandText = "SELECT id_commande, reference_commande, date_commande,"+
                                    "date_demandee, id_type, id_contact, id_facture, id_shipment," +
                                    "id_personne, id_etat, id_client FROM commande;";
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int l_IDCommande = reader.GetInt32(0);
                        string l_ReferenceCommande = reader.GetString(1);
                        DateTime l_DateCommande = reader.GetDateTime(2);
                        DateTime l_DateDemandee = reader.GetDateTime(3);
                        int l_IDType = reader.GetInt32(4);
                        int l_IDContact = reader.GetInt32(5);
                        int l_IDFacture = reader.GetInt32(6);
                        int l_IDShipment = reader.GetInt32(7);
                        int l_IDPersonne = reader.GetInt32(8);
                        int l_IDEtat = reader.GetInt32(9);
                        int l_IDClient = reader.GetInt32(10);

                        l_Commande = new cls_Commande(l_IDCommande, l_ReferenceCommande, l_DateCommande, 
                            l_DateDemandee,l_IDClient, l_IDContact, l_IDEtat, l_IDFacture, l_IDPersonne, 
                            l_IDShipment, l_IDType);
                        l_ListeCommande.Add(l_IDCommande, l_Commande);
                    }
                }
            }
            return l_ListeCommande;
        }

        //public static void InsertClient(cls_Client pClient)
        //{
        //    using (NpgsqlCommand cmd = new NpgsqlCommand())
        //    {
        //        cmd.Connection = c_Cnn;

        //        // Retrieve all rows
        //        cmd.CommandText = "insert into client (id_client, raison_sociale_client, telephone, mail)"
        //             + "values (" + pClient.getID() + ",'" + pClient.RaisonSociale + "','" + pClient.Telephone + "','" +
        //             pClient.eMail + "');";
        //        int l_Nb = cmd.ExecuteNonQuery();

        //    }
        //}

        //public static void ModifClient(cls_Client pClient)
        //{
        //    using (NpgsqlCommand cmd = new NpgsqlCommand())
        //    {
        //        cmd.Connection = c_Cnn;

        //        // Retrieve all rows
        //        cmd.CommandText = "update client set raison_sociale_client='" + pClient.RaisonSociale +
        //            "', telephone='" + pClient.Telephone + "', mail='" + pClient.eMail + "' WHERE id_client="
        //            + pClient.getID();
        //        int l_Nb = cmd.ExecuteNonQuery();

        //    }
        //}

        //public static void SupprClient(cls_Client pClient)
        //{
        //    using (NpgsqlCommand cmd = new NpgsqlCommand())
        //    {
        //        cmd.Connection = c_Cnn;

        //        cmd.CommandText = "DELETE FROM client WHERE id_client=" + pClient.getID();
        //        int l_Nb = cmd.ExecuteNonQuery();

        //    }
        //}
    }
}
