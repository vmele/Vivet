﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;



namespace E4_APP_VMELE
{
    public partial class frm_DetailCommande : Form
    {
        public frm_DetailCommande()
        {
            InitializeComponent();
        }

        private void nouveauMailSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                Outlook.Application outlookApp = new Outlook.Application();
                Outlook.MailItem mailItem = (Outlook.MailItem)outlookApp.CreateItem(Outlook.OlItemType.olMailItem);
                mailItem.Subject = Form.ActiveForm.Name;
                mailItem.To = "contact@valentinmele.fr";
                mailItem.Body = "This is the message.";
                mailItem.Importance = Outlook.OlImportance.olImportanceLow;
                mailItem.Display(false);
            }
            catch (Exception eX)
            {
                throw new Exception("cDocument: Error occurred trying to Create an Outlook Email"
                                    + Environment.NewLine + eX.Message);
            }
        }
    }
    
}
