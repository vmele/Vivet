﻿using GSB_DAL_DLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSB_Modele_DLL
{
    public class cls_Commande : cls_ObjetBase
    {

        private string c_RefCommande;
        private DateTime c_DateCommande;
        private DateTime c_DateVoulue;
        private int c_IDClient;
        private int c_IDContact;
        private int c_IDEtat;
        private int c_IDFacture;
        private int c_IDPersonne;
        private int c_IDShipment;
        private int c_IDType;
        private List<cls_LigneCommande> c_ListeLigneCommande;

        /// <summary>
        /// Constructeur de cls_Commande
        /// </summary>
        /// <param name="pIDCommande">ID de la commande</param>
        /// <param name="pRefCommande">Référence commande</param>
        /// <param name="pDateCommande">Date de la commande</param>
        /// <param name="pDateVoulue">Date demandée par le client</param>
        /// <param name="pIDContact">ID du moyen de contact de la commande</param>
        /// <param name="pIDEtat">ID de l'état de la commande</param>
        /// <param name="pIDFacture">ID de la facture liée à la commande</param>
        /// <param name="pIDPersonne">ID de la personne créant la commande</param>
        /// <param name="pIDShipment">ID du shipment</param>
        /// <param name="pIDType">ID du type de la commande</param>
        public cls_Commande(int pIDCommande, string pRefCommande, DateTime pDateCommande, DateTime pDateVoulue, int pIDClient,
           int pIDContact, int pIDEtat, int pIDFacture, int pIDPersonne, int pIDShipment, int pIDType) : base(pIDCommande)
        {
            c_RefCommande = pRefCommande;
            c_DateCommande = pDateCommande;
            setDateVoulue(pDateVoulue);
            c_IDClient = pIDClient;
            c_IDContact = pIDContact;
            c_IDEtat = pIDEtat;
            c_IDFacture = pIDFacture;
            c_IDPersonne = pIDPersonne;
            c_IDShipment = pIDShipment;
            c_IDType = pIDType;
            c_ListeLigneCommande = new List<cls_LigneCommande>();

        }

        /// <summary>
        /// Empêche de set la date voulue à une date inférieure à aujourd'hui.
        /// </summary>
        /// <param name="pDateVoulue">Date voulue par le client.</param>
        public void setDateVoulue(DateTime pDateVoulue)
        {
            if (pDateVoulue < DateTime.Now)
            {
                throw new Exception("La date demandée par le client ne peut-être inférieure à celle d'aujourd'hui.");
            }
            else
            {
                c_DateVoulue = pDateVoulue;
            }
        }

        // TODO : Créer et charger la liste des types de cde dans le modèle et faire get typebyID.
        public override string ToString()
        {
            return c_RefCommande;
        }

        public string RefCommande
        {
            get
            {
                return c_RefCommande;
            }
            set
            {
                c_RefCommande = value;
            }
        }
        public DateTime DateCommande
        {
            get
            {
                return c_DateCommande;
            }
            set
            {
                c_DateCommande = value;
            }
        }
        public DateTime DateVoulue
        {
            get
            {
                return c_DateVoulue;
            }
        }
        public int idContact
        {
            get
            {
                return c_IDContact;
            }
            set
            {
                c_IDContact = value;
            }
        }
        public int idEtat
        {
            get
            {
                return c_IDEtat;
            }
            set
            {
                c_IDEtat = value;
            }
        }
        public int idFacture
        {
            get
            {
                return c_IDFacture;
            }
            set
            {
                c_IDFacture = value;
            }
        }
        public int idPersonne
        {
            get
            {
                return c_IDPersonne;
            }
            set
            {
                c_IDPersonne = value;
            }
        }
        public int idShipment
        {
            get
            {
                return c_IDShipment;
            }
            set
            {
                c_IDShipment = value;
            }
        }
        public int idType
        {
            get
            {
                return c_IDType;
            }
            set
            {
                c_IDType = value;
            }
        }
        public List<cls_LigneCommande> ListeLignesCommande
        {
            get
            {
                return c_ListeLigneCommande;
            }
            set
            {
                c_ListeLigneCommande = value;
            }
        }
    }
}
