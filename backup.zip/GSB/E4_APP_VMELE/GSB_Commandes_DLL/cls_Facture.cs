﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSB_Modele_DLL
{
    public class cls_Facture : cls_ObjetBase
    {
        private int c_IDFacture;
        private string c_RefFacture;
        private int c_IDCommande;

        /// <summary>
        /// Constructeur de cls_Facture
        /// </summary>
        /// <param name="pIDFacture">id de la facture</param>
        /// <param name="c_RefFacture">Rérérence de la facture</param>
        /// <param name="pIDCommande">ID de la commande liée</param>
        public cls_Facture(int pIDFacture, string c_RefFacture, int pIDCommande) 
            : base(pIDFacture)
        {
            setRefFacture(pIDFacture);
            c_IDCommande = pIDCommande;
        }

        /// <summary>
        /// Compose la réf facture de FA/00 + ID de la facture
        /// </summary>
        /// <param name="pIDFacture"></param>
        public void setRefFacture(int pIDFacture)
        {
            c_RefFacture = "FA/00" + pIDFacture;
        }

        public int idFacture
        {
            get
            {
                return c_IDFacture;
            }
            set
            {
                c_IDFacture = value;
            }
        }
        public string RefFacture
        {
            get
            {
                return c_RefFacture;
            }
        }
        public int idCommande
        {
            get
            {
                return c_IDCommande;
            }
            set
            {
                c_IDCommande = value;
            }
        }
    }
}
